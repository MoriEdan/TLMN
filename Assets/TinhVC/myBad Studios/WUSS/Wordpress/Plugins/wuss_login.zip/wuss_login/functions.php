<?php

	function SendNode($node_name, $fields="")
	{
		echo base64_encode("<$node_name>$fields\n");
	}
		
	function SendField($field_name, $field_value)
	{
		echo base64_encode("[$field_name]$field_value\n");
	}
	
	function PrintError($message, $errno='', $error='')
	{
		SendNode("status", "success=false; message=$message");
	
		if ('' != $errno)
			SendField("errorno", $errno);
	
		if ('' != $error)
			SendField("error", $error);
	}
	
	function wuss_table_prefix($force_local = false)
	{
		global $wpdb;
		
		if (function_exists('is_multisite') && is_multisite() && !$force_local)
			return get_option("wuss_table_prefix");
		else
			return $wpdb->prefix . get_option("wuss_table_prefix");
	}

	function Postedi($field)
	{
		global $mysqli;
		return (int)Postedf($field);
	}

	function Postedf($field)
	{
		global $mysqli;
		return isset($_POST[$field]) ? sanitize_text_field( strip_tags($_POST[$field] ) ) : 0;
	}

	function Posted($field)
	{
		global $mysqli;
		return isset($_POST[$field]) ? sanitize_text_field( strip_tags($_POST[$field] ) ) : "";
	}

?>