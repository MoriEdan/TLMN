<?php

session_start();

/*
Plugin Name: WUSS Login
Plugin URI: http://wuss.mybadstudios.com/
Description: A plugin that allows you to use Wordpress's user database as your Unity login
Version: 1.0
Author: myBad Studios
Author URI: http://www.mybadstudios.com
*/

//if these values don't exist, create them. If they do, then skip creating them
add_option("wuss_db_version", "1.0");
add_option("wuss_table_prefix", "wuss_");

if ( file_exists( dirname(__FILE__) . "/wuss_login_Widget.php"))
	include_once("wuss_login_Widget.php");
?>