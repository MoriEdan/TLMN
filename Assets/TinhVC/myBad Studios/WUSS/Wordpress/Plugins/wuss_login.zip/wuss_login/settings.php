<?php
//required to use WP. Set to false when using from Unity. Set to true when using in WP.
//In unity we will pass in a "Unity" field so let's test for that now...
$unity = isset($_POST['unity']);

define('WP_USE_THEMES', !isSet($unity) ? true : false );
define('CALLED_FROM_GAME', WP_USE_THEMES == false ? true : false);
define('WUSSACTION', isSet( $_POST['wuss'] ) ? strtolower( trim( $_POST['wuss'] ) ) : "");

$name_was_set = isset($_POST["name"]);
if($name_was_set)
{
	$wuss_name = $_POST["name"];
	unset($_POST["name"]);
}

//this kit is intended to be installed in wp-content/plugins/wuss_logins
//so we need to go back 3 folders to find this file. Adjust as necesarry
require_once(dirname(__FILE__) . '/../../../wp-config.php');

if ($name_was_set)
{
	$_POST["name"] = $wuss_name;
}

?>